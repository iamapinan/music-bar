#!/usr/bin/env python3
"""Small CLI for controlling Music Bar through its HTTP API."""

from __future__ import annotations

import argparse
import json
import os
import sys
import urllib.error
import urllib.parse
import urllib.request


def shorten(value: str, limit: int = 500) -> str:
    value = " ".join(value.split())
    return value if len(value) <= limit else value[:limit] + "..."


def compact_json(value: object) -> str:
    return json.dumps(value, ensure_ascii=False, indent=2)


def maybe_json(value: object) -> object:
    if isinstance(value, str):
        try:
            return json.loads(value)
        except json.JSONDecodeError:
            return value
    return value


class MusicBarClient:
    def __init__(self, base_url: str, tenant: str | None, cookie: str | None = None, api_key: str | None = None):
        self.base_url = base_url.rstrip("/")
        self.tenant = tenant
        self.cookie = cookie
        self.api_key = api_key

    def request(self, method: str, path: str, body: object | None = None, require_tenant: bool = True) -> object:
        if require_tenant and not self.tenant:
            raise SystemExit("Missing tenant slug. Pass --tenant or set MUSIC_BAR_TENANT_SLUG.")

        url = self.base_url + path
        data = None
        headers = {
            "accept": "application/json",
        }
        if self.tenant:
            headers["x-tenant-slug"] = self.tenant
        if body is not None:
            data = json.dumps(body).encode("utf-8")
            headers["content-type"] = "application/json"
        if self.cookie:
            headers["cookie"] = self.cookie
        if self.api_key:
            headers["x-api-key"] = self.api_key

        req = urllib.request.Request(url, data=data, headers=headers, method=method)
        try:
            with urllib.request.urlopen(req, timeout=30) as resp:
                raw = resp.read().decode("utf-8")
                return json.loads(raw) if raw else {"success": True}
        except urllib.error.HTTPError as exc:
            raw = exc.read().decode("utf-8", errors="replace")
            content_type = exc.headers.get("content-type", "")
            try:
                payload = json.loads(raw) if "json" in content_type or raw.lstrip().startswith("{") else None
            except json.JSONDecodeError:
                payload = None
            if payload is None:
                if "html" in content_type or raw.lstrip().lower().startswith("<!doctype html"):
                    payload = {"error": f"Non-JSON response ({content_type or 'unknown content-type'}): {shorten(raw, 120)}"}
                else:
                    payload = {"error": shorten(raw) or exc.reason}
            raise SystemExit(f"HTTP {exc.code}: {compact_json(payload)}") from exc
        except urllib.error.URLError as exc:
            raise SystemExit(f"Connection failed: {exc.reason}") from exc

    def list_playlists(self) -> object:
        return self.request("GET", "/api/playlists")

    def get_active_playlists(self) -> object:
        settings = self.request("GET", "/api/settings")
        if isinstance(settings, dict):
            return {"active_playlist_ids": maybe_json(settings.get("active_playlist_ids", []))}
        return settings

    def list_playlist_songs(self, playlist_id: int) -> object:
        return self.request("GET", f"/api/playlists/{playlist_id}/songs")

    def list_stations(self) -> object:
        return self.request("GET", "/api/stations", require_tenant=False)

    def switch_playlists(self, playlist_ids: list[int]) -> object:
        return self.request("PATCH", "/api/settings", {
            "key": "active_playlist_ids",
            "value": playlist_ids,
        })

    def search_song(self, query: str) -> object:
        q = urllib.parse.urlencode({"q": query, "type": "video"})
        return self.request("GET", f"/api/youtube/search?{q}")

    def request_song(
        self,
        youtube_id: str,
        title: str,
        thumbnail: str | None,
        requested_by: str | None,
        device_id: str | None,
    ) -> object:
        return self.request("POST", "/api/requests", {
            "youtube_id": youtube_id,
            "title": title,
            "thumbnail": thumbnail,
            "duration": None,
            "audio_url": None,
            "requested_by": requested_by,
            "device_id": device_id,
        })

    def list_requests(self, device_id: str | None = None) -> object:
        path = "/api/requests"
        if device_id:
            path += "?" + urllib.parse.urlencode({"device_id": device_id})
        return self.request("GET", path)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Control Music Bar through its HTTP API.")
    parser.add_argument("--base-url", default=os.getenv("MUSIC_BAR_BASE_URL", "http://localhost:3000"))
    parser.add_argument("--tenant", default=os.getenv("MUSIC_BAR_TENANT_SLUG"))
    parser.add_argument("--cookie", default=os.getenv("MUSIC_BAR_COOKIE"))
    parser.add_argument("--api-key", default=os.getenv("MUSIC_BAR_API_KEY"))
    sub = parser.add_subparsers(dest="command", required=True)

    sub.add_parser("list-playlists")
    sub.add_parser("get-active-playlists")

    playlist_songs = sub.add_parser("list-playlist-songs", aliases=["list-music"])
    playlist_songs.add_argument("playlist_id", type=int)

    sub.add_parser("list-stations")

    switch = sub.add_parser("switch-playlists")
    switch.add_argument("playlist_ids", nargs="+", type=int)

    sub.add_parser("clear-active-playlists")

    search = sub.add_parser("search-song")
    search.add_argument("query")

    req = sub.add_parser("request-song")
    req.add_argument("--youtube-id", required=True)
    req.add_argument("--title", required=True)
    req.add_argument("--thumbnail")
    req.add_argument("--requested-by", default="AI")
    req.add_argument("--device-id", default="ai-agent")

    first = sub.add_parser("request-first-search-result")
    first.add_argument("query")
    first.add_argument("--requested-by", default="AI")
    first.add_argument("--device-id", default="ai-agent")

    pending = sub.add_parser("list-requests")
    pending.add_argument("--device-id")

    return parser


def main() -> int:
    args = build_parser().parse_args()
    client = MusicBarClient(args.base_url, args.tenant, args.cookie, args.api_key)

    if args.command == "list-playlists":
        result = client.list_playlists()
    elif args.command == "get-active-playlists":
        result = client.get_active_playlists()
    elif args.command in {"list-playlist-songs", "list-music"}:
        result = client.list_playlist_songs(args.playlist_id)
    elif args.command == "list-stations":
        result = client.list_stations()
    elif args.command == "switch-playlists":
        result = client.switch_playlists(args.playlist_ids)
    elif args.command == "clear-active-playlists":
        result = client.switch_playlists([])
    elif args.command == "search-song":
        result = client.search_song(args.query)
    elif args.command == "request-song":
        result = client.request_song(args.youtube_id, args.title, args.thumbnail, args.requested_by, args.device_id)
    elif args.command == "request-first-search-result":
        search = client.search_song(args.query)
        items = search.get("items") if isinstance(search, dict) else None
        if not items:
            raise SystemExit("No search results.")
        song = items[0]
        result = client.request_song(
            str(song["id"]),
            str(song["title"]),
            song.get("thumbnail"),
            args.requested_by,
            args.device_id,
        )
    elif args.command == "list-requests":
        result = client.list_requests(args.device_id)
    else:
        raise SystemExit(f"Unknown command: {args.command}")

    print(compact_json(result))
    return 0


if __name__ == "__main__":
    sys.exit(main())
