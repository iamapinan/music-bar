# Music Bar API Reference

## Tenant selection

Send `x-tenant-slug: <slug>` on every request. Most endpoints can also infer a tenant from a logged-in active tenant cookie, but AI/API callers should be explicit.

## API key authentication

For automation-safe admin actions, send either:

```http
x-api-key: <key>
```

or:

```http
authorization: Bearer <key>
```

The server must configure `MUSIC_BAR_API_KEYS`. Preferred JSON form:

```json
[
  {
    "name": "ai-main",
    "keyHash": "sha256:<sha256-of-key>",
    "tenant": "main",
    "role": "admin",
    "scopes": ["playlist:switch"]
  }
]
```

For local testing only, raw comma-separated keys are also accepted and grant `admin` / `*` / all tenants.

## List playlists

```http
GET /api/playlists
x-tenant-slug: <slug>
```

Public. Returns playlists ordered default-first/newest-first. Useful fields:

- `id`: numeric playlist ID
- `name`
- `is_default`
- `is_enabled`
- `song_count`
- `cover_thumbnail`

## List songs/music in a playlist

```http
GET /api/playlists/{playlist_id}/songs
x-tenant-slug: <slug>
```

Public. Returns available songs in playlist order. Useful fields:

- `id`: playlist-song row ID
- `playlist_id`
- `song_id`
- `position`
- `youtube_id`
- `title`
- `thumbnail`
- `duration`
- `artist`
- `audio_url`: proxied stream URL when audio is available

## List stations

```http
GET /api/stations
```

Public. Does not require a tenant slug. Returns active stations ordered by creation time. Useful fields:

- `id`: tenant ID
- `slug`: use this as `x-tenant-slug` for playlist and request operations
- `name`
- `display_name`
- `logo_url`
- `playlist_count`
- `song_count`
- `cover_thumbnail`

## Switch active playlist(s)

```http
PATCH /api/settings
x-tenant-slug: <slug>
x-api-key: <key>
content-type: application/json

{"key":"active_playlist_ids","value":[12,18]}
```

Owner/admin only by session cookie, or API key with `playlist:switch` scope. `value` must be an array of numeric playlist IDs.

- Multiple IDs: player rotates across selected playlists.
- Empty array: app falls back to the default playlist.
- Invalid/disabled IDs are filtered by player/mobile init behavior; still prefer selecting enabled playlists from `GET /api/playlists`.

## Get active playlists

```http
GET /api/settings
x-tenant-slug: <slug>
```

Public response includes safe settings such as `active_playlist_ids`. Use this to verify `switch-playlists` from a black-box Skill test.

## Set default playlist

```http
PATCH /api/playlists
x-tenant-slug: <slug>
cookie: <music_bar_session=...>
content-type: application/json

{"id":12,"is_default":true}
```

Owner/admin only. This also clears `active_playlist_ids` to `[]`.

## Search YouTube songs

```http
GET /api/youtube/search?q=<query>&type=video
x-tenant-slug: <slug>
```

Public. Returns `{ "items": [...] }`. Song request fields map as:

- `youtube_id`: `items[n].id`
- `title`: `items[n].title`
- `thumbnail`: `items[n].thumbnail`

## Submit song request

```http
POST /api/requests
x-tenant-slug: <slug>
content-type: application/json

{
  "youtube_id": "dQw4w9WgXcQ",
  "title": "Song title",
  "thumbnail": "https://...",
  "duration": null,
  "audio_url": null,
  "requested_by": "AI",
  "device_id": "ai-agent"
}
```

Public, rate limited to 10 requests per minute per IP. Required: `youtube_id`, `title`. Defaults `requested_by` to `ลูกค้า` when omitted.

Common errors:

- `400`: missing song fields or duplicate pending request (`เพลงนี้อยู่ในคิวแล้ว`)
- `403`: requests disabled (`ขณะนี้ปิดรับขอเพลง`)
- `429`: too many requests

## List pending requests

```http
GET /api/requests
x-tenant-slug: <slug>
cookie: <music_bar_session=...>
```

Staff/admin/owner only. Public callers can only query their own pending requests with `?device_id=<device_id>`.
