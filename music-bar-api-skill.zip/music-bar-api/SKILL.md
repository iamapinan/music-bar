---
name: music-bar-api
description: Control and inspect a Music Bar instance through its HTTP API. Use when Codex or another AI agent needs to list stations, list playlists, list songs/music in a playlist, switch the active playlist, reset playback to the default playlist, search YouTube songs, submit customer song requests, or inspect pending requests for a Music Bar tenant via API.
---

# Music Bar API

Use this skill to operate Music Bar through API calls instead of browser UI clicks.

## Quick Start

Prefer the bundled helper for live operations:

```bash
python scripts/music_bar_api.py --base-url http://localhost:3000 --tenant main list-playlists
python scripts/music_bar_api.py --base-url http://localhost:3000 --tenant main list-playlist-songs 12
python scripts/music_bar_api.py --base-url http://localhost:3000 list-stations
python scripts/music_bar_api.py --base-url http://localhost:3000 --tenant main --api-key "$MUSIC_BAR_API_KEY" switch-playlists 12 18
python scripts/music_bar_api.py --base-url http://localhost:3000 --tenant main request-first-search-result "plastic love" --requested-by "AI"
```

Environment variables can replace repeated flags:

- `MUSIC_BAR_BASE_URL`: app origin, for example `http://localhost:3000`
- `MUSIC_BAR_TENANT_SLUG`: tenant slug sent as `x-tenant-slug`
- `MUSIC_BAR_API_KEY`: API key sent as `x-api-key` for automation-safe admin actions
- `MUSIC_BAR_COOKIE`: optional session cookie string for admin-only calls

Read [references/api.md](references/api.md) when payload details, status codes, or manual `curl` calls are needed.

## Workflow

1. Identify the tenant slug. Use `--tenant` or `MUSIC_BAR_TENANT_SLUG`; public endpoints also accept `?tenant=<slug>`, but the helper uses `x-tenant-slug`.
2. For station discovery, run `list-stations` first, then use the returned station `slug` as the tenant slug for playlist or request operations.
3. For playlist inspection, run `list-playlists`, then `list-playlist-songs <playlist_id>` when the user asks for music inside a playlist.
4. For playlist switching, list playlists first unless the user gave numeric playlist IDs.
5. Switch active playlists with `switch-playlists <id...>`. Passing more than one ID enables continuous playback across those playlists. Use `clear-active-playlists` to fall back to the default playlist. Verify with `get-active-playlists`.
6. For song requests, search first unless the user supplied exact YouTube metadata. Use `request-first-search-result` only when the user accepts the top search result.
7. Report the API response succinctly: station names/slugs, playlist names/IDs selected, song titles, request ID, and any error message returned by the API.

## Authentication Rules

- Public: `GET /api/stations` needs no tenant. `GET /api/playlists`, `GET /api/playlists/:id/songs`, `GET /api/settings`, `GET /api/youtube/search`, and `POST /api/requests` can run with only a tenant slug.
- Admin automation: `PATCH /api/settings` for `active_playlist_ids` accepts `MUSIC_BAR_API_KEY` / `--api-key` when the server is configured with a key scoped for `playlist:switch`.
- Browser admin fallback: owner/admin session cookie can still be provided through `MUSIC_BAR_COOKIE` or `--cookie`.
- Staff/admin: reading or updating all pending requests requires authenticated staff/admin access.

If an admin-only call returns `401` or `403`, explain that an authenticated session cookie or logged-in browser/API context is required.

## Safety

- Do not invent playlist IDs. Resolve names to IDs from `list-playlists`, call `switch-playlists`, then confirm with `get-active-playlists`.
- Do not submit multiple song requests unless the user explicitly asked for multiple songs.
- If a request fails because the song is already queued or requests are disabled, return the API's Thai error text as-is.
